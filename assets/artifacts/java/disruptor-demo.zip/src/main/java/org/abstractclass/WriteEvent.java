package org.abstractclass;

/**
 * @author Anindya Chatterjee.
 */
public class WriteEvent {

    private String message;

    public void set(String message){
        this.message = message;
    }

    public String get() {
        return this.message;
    }
}
